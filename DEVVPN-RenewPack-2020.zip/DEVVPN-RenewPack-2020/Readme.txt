1. Ensure OpenVPN program is not running.

2. Start Powershell as normal user. (non admin mode)

3. Run command "cd <path to folder>" (e.g D:\DEV-VPN-Package)

4. Run the script 02-Install-VPN-NormalUser to install the new certificate and update OpenVPN config.
