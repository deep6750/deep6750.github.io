$ErrorActionPreference = "Stop"
$PSPath = $PSScriptRoot

<# Import VPN Certificate #>

$DEVVPN2020_Thumbprint = "98AFA72BF508FE77368A70B60015456E38BC6837"

$Cert = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Thumbprint -eq $DEVVPN2020_Thumbprint } | Select-Object

Write-Host ("FOUND: {0} Certificates" -f ($Cert | Measure-Object).Count) -ForegroundColor Yellow

if (($Cert | Measure-Object).Count -gt 0) {

    Write-Host -ForegroundColor Yellow "FOUND: Deleting existing key ..."
    Remove-Item -Path $Cert[0].PSPath
}

Write-Host -ForegroundColor Green "STARTED: Import VPN Certificate ..."
$PfxPassword = ConvertTo-SecureString "~Jtc2020" -AsPlainText -Force
Import-PfxCertificate -FilePath "$PSPath\certs\DEVVPN-2020.pfx" -CertStoreLocation Cert:\CurrentUser\My -Password $PfxPassword
Write-Host -ForegroundColor Green "COMPLETED: Import VPN Certificate ..."

<# Copy OpenVPN Client Config #>

$ConfigPath = $env:USERPROFILE + "\OpenVPN\config"

Write-Host -ForegroundColor Green "STARTED: Creating OpenVPN Profile ..."

if(-not (Test-Path -PathType Container $ConfigPath))
{
    Write-Host -ForegroundColor Green ("Creating Folder '{0}'..." -f $ConfigPath)
    New-Item -Path $ConfigPath -ItemType Directory
}

Write-Host -ForegroundColor Green ("Copy VPN Config to '{0}'..." -f $ConfigPath)
Copy-Item -Path "$PSPath\\openvpn\\client.ovpn" -Destination "$ConfigPath\\client.ovpn" -Force

Write-Host -ForegroundColor Green ("Copy Certificates to '{0}'..." -f $ConfigPath)
Copy-Item -Path "$PSPath\\certs\\DEVVPN-CA.crt" -Destination "$ConfigPath\\DEVVPN-CA.crt" -Force
Copy-Item -Path "$PSPath\\certs\\ta.key" -Destination "$ConfigPath\\ta.key" -Force

Write-Host -ForegroundColor Green "COMPLETED: Creating OpenVPN Profile ..."