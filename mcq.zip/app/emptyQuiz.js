{
    "quiz": {
        "id": 1,
        "name": "<Enter Quiz Name>",
        "description": "<Enter Quiz Description>"
    },
    "questions": [{
        "id": 101,
        "name": "Which of the following assemblies can be stored in Global Assembly Cache?", 
        "questionTypeId": 1,
        "options": [
            { "Id": 1001, "questionId": 101, "name": "<Add your option here>", "isAnswer": true },
            { "Id": 1002, "questionId": 101, "name": "<Add your option here>", "isAnswer": false },
            { "Id": 1003, "questionId": 101, "name": "<Add your option here>", "isAnswer": false },
            { "Id": 1004, "questionId": 101, "name": "<Add your option here>", "isAnswer": false }],
        "questionType": { "id": 1, "name": "Multiple Choice", "isActive": true }
    }]
}